"""Legacy FFT learned roles module removed."""

raise ImportError(
    "somabrain.math.learned_roles has been removed; use somabrain.math.bhdc_encoder instead"
)
