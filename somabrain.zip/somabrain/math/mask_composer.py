"""Legacy mask composer module removed in favour of BHDC primitives."""

raise ImportError(
    "somabrain.math.mask_composer has been removed; use somabrain.math.bhdc_encoder instead"
)
